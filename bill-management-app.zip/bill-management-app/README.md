# Bill Management System — Android App (Capacitor)

A fully offline bill-tracking app: add bills, set due dates, mark them paid,
auto-roll recurring bills to next month, and see totals/overdue at a glance.
All data is stored locally on the device (via Capacitor's `Preferences`
plugin, i.e. native Android SharedPreferences) — **no internet connection or
backend is required at any point.**

## Repository layout

```
.
├── .github/workflows/android-build.yml   # CI: builds debug/release APK + AAB
├── src/                                   # The web app (HTML/CSS/JS), bundled into the APK
│   ├── index.html
│   ├── css/style.css
│   └── js/{app.js, storage.js}
├── android/                               # Native Android/Gradle project
│   ├── app/                               # App module (manifest, icons, MainActivity)
│   ├── gradle/wrapper/                    # Gradle wrapper config
│   ├── gradlew / gradlew.bat
│   ├── build.gradle / settings.gradle / variables.gradle
│   └── capacitor.settings.gradle          # Plugin module wiring (auto-regenerated)
├── capacitor.config.json                  # Capacitor config (appId, webDir, plugins)
├── package.json / package-lock.json
└── README.md
```

## Requirements

- Node.js 20+
- JDK 17
- Android SDK (Android Studio, or the command-line tools)

## Local development

```bash
npm install
npx cap sync android   # copies src/ into android/app/src/main/assets/public
                        # and wires up native plugin projects
npx cap open android    # opens the project in Android Studio
```

Or build from the command line:

```bash
cd android
./gradlew assembleDebug      # debug APK
./gradlew assembleRelease    # release APK
./gradlew bundleRelease      # release AAB (for Play Store)
```

> **Note on the Gradle wrapper jar:** `gradle-wrapper.jar` is a binary file
> and is intentionally not committed to the repo. `gradlew`/`gradlew.bat`
> and `gradle-wrapper.properties` **are** committed. If you're building
> locally for the first time and don't yet have a wrapper jar, run
> `gradle wrapper --gradle-version 8.7 --distribution-type all` once from
> the `android/` directory (requires a local Gradle install) — CI does this
> automatically on every run, so no manual step is needed there.

## CI/CD — GitHub Actions

`.github/workflows/android-build.yml` runs on every push/PR to `main`/`master`
and on manual dispatch. It:

1. Installs Node deps (`npm install`) and Java 17 + Android SDK.
2. Runs `npx cap sync android` to copy the web app into the native project.
3. Provisions Gradle 8.7 and regenerates the Gradle wrapper.
4. Builds `assembleDebug`, `assembleRelease`, and `bundleRelease`.
5. Uploads all three as workflow artifacts (**Actions tab → workflow run →
   Artifacts**): `app-debug-apk`, `app-release-apk`, `app-release-aab`.

The build succeeds out of the box with **no secrets or manual setup
required** — the release build is simply unsigned until you configure
signing (see below).

## Signing release builds (optional)

To produce a Play-Store-ready **signed** release APK/AAB, add these
repository secrets (Settings → Secrets and variables → Actions):

| Secret                  | Value                                              |
|-------------------------|-----------------------------------------------------|
| `CI_KEYSTORE_BASE64`    | `base64 -w 0 your-release-key.jks` output            |
| `CI_KEYSTORE_PASSWORD`  | Keystore password                                    |
| `CI_KEY_ALIAS`          | Key alias                                            |
| `CI_KEY_PASSWORD`       | Key password                                         |

When these are present, the workflow decodes the keystore and signs
`assembleRelease`/`bundleRelease` automatically. When absent, the same
tasks still run and succeed — they just produce unsigned output.

## Offline support

- The entire UI (`src/`) is bundled inside the APK at build time — nothing
  is fetched over the network at runtime.
- Bill data is persisted with `@capacitor/preferences` (native storage),
  so it survives app restarts, device reboots, and airplane mode.
- No `INTERNET` permission is requested in `AndroidManifest.xml`.

## App ID

`com.billmanagement.app` — change this in `capacitor.config.json` and
`android/app/build.gradle` (`applicationId`/`namespace`) before publishing
under your own account.
