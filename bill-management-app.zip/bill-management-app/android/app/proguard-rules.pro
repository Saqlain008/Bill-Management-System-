# Add project specific ProGuard rules here.
# Since minification is disabled by default for this project (see app/build.gradle),
# these rules only take effect if you later enable minifyEnabled true.

-keep public class * extends com.getcapacitor.Plugin
-keep public class com.getcapacitor.Plugin
-keep public class com.getcapacitor.PluginCall
