package com.billmanagement.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
}
