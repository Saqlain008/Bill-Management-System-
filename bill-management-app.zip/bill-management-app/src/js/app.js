(function () {
  "use strict";

  let bills = [];
  let currentFilter = "all";

  const el = {
    list: document.getElementById("billList"),
    totalDue: document.getElementById("totalDue"),
    totalOverdue: document.getElementById("totalOverdue"),
    totalPaid: document.getElementById("totalPaid"),
    fab: document.getElementById("fab"),
    overlay: document.getElementById("modalOverlay"),
    form: document.getElementById("billForm"),
    modalTitle: document.getElementById("modalTitle"),
    billId: document.getElementById("billId"),
    billName: document.getElementById("billName"),
    billCategory: document.getElementById("billCategory"),
    billAmount: document.getElementById("billAmount"),
    billDueDate: document.getElementById("billDueDate"),
    billRecurring: document.getElementById("billRecurring"),
    billNotes: document.getElementById("billNotes"),
    cancelBtn: document.getElementById("cancelBtn"),
    deleteBtn: document.getElementById("deleteBtn"),
    toast: document.getElementById("toast"),
    chips: document.querySelectorAll(".chip"),
  };

  const categoryIcons = {
    "Utilities": "💡",
    "Rent / Mortgage": "🏠",
    "Internet / Phone": "📶",
    "Insurance": "🛡️",
    "Subscription": "🔁",
    "Credit Card": "💳",
    "Other": "🧾",
  };

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function startOfToday() {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  }

  function billStatus(bill) {
    if (bill.paid) return "paid";
    const due = new Date(bill.dueDate + "T00:00:00");
    const today = startOfToday();
    const diffDays = Math.round((due - today) / 86400000);
    if (diffDays < 0) return "overdue";
    if (diffDays <= 5) return "due-soon";
    return "upcoming";
  }

  function formatMoney(n) {
    return "$" + Number(n || 0).toFixed(2);
  }

  function formatDate(dateStr) {
    const d = new Date(dateStr + "T00:00:00");
    return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  }

  function showToast(msg) {
    el.toast.textContent = msg;
    el.toast.classList.remove("hidden");
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => el.toast.classList.add("hidden"), 1800);
  }

  async function persist() {
    await BillStorage.saveBills(bills);
  }

  function render() {
    // Summary
    const unpaid = bills.filter((b) => !b.paid);
    const totalDue = unpaid.reduce((sum, b) => sum + Number(b.amount), 0);
    const overdueCount = unpaid.filter((b) => billStatus(b) === "overdue").length;
    const now = new Date();
    const paidThisMonth = bills
      .filter(
        (b) =>
          b.paid &&
          b.paidOn &&
          new Date(b.paidOn).getMonth() === now.getMonth() &&
          new Date(b.paidOn).getFullYear() === now.getFullYear()
      )
      .reduce((sum, b) => sum + Number(b.amount), 0);

    el.totalDue.textContent = formatMoney(totalDue);
    el.totalOverdue.textContent = String(overdueCount);
    el.totalPaid.textContent = formatMoney(paidThisMonth);

    // Filtered + sorted list
    let visible = bills.slice();
    if (currentFilter === "unpaid") visible = visible.filter((b) => !b.paid);
    else if (currentFilter === "paid") visible = visible.filter((b) => b.paid);
    else if (currentFilter === "overdue")
      visible = visible.filter((b) => billStatus(b) === "overdue");

    visible.sort((a, b) => a.dueDate.localeCompare(b.dueDate));

    el.list.innerHTML = "";
    if (visible.length === 0) {
      el.list.innerHTML = `<div class="empty-state">No bills here. Tap + to add one.</div>`;
      return;
    }

    for (const bill of visible) {
      const status = billStatus(bill);
      const card = document.createElement("div");
      card.className = "bill-card " + status;
      card.innerHTML = `
        <button class="pay-toggle ${bill.paid ? "checked" : ""}" data-action="toggle" data-id="${bill.id}">
          ${bill.paid ? "✓" : ""}
        </button>
        <div class="bill-icon">${categoryIcons[bill.category] || "🧾"}</div>
        <div class="bill-info" data-action="edit" data-id="${bill.id}">
          <div class="name">${escapeHtml(bill.name)}</div>
          <div class="meta">${bill.category} · Due ${formatDate(bill.dueDate)}${bill.recurring ? " · Monthly" : ""}</div>
        </div>
        <div class="bill-amount" data-action="edit" data-id="${bill.id}">
          <div class="amt">${formatMoney(bill.amount)}</div>
          <div class="status ${status}">${statusLabel(status)}</div>
        </div>
      `;
      el.list.appendChild(card);
    }
  }

  function statusLabel(status) {
    switch (status) {
      case "paid": return "Paid";
      case "overdue": return "Overdue";
      case "due-soon": return "Due soon";
      default: return "Upcoming";
    }
  }

  function escapeHtml(str) {
    const d = document.createElement("div");
    d.textContent = str;
    return d.innerHTML;
  }

  function openModal(bill) {
    el.form.reset();
    if (bill) {
      el.modalTitle.textContent = "Edit Bill";
      el.billId.value = bill.id;
      el.billName.value = bill.name;
      el.billCategory.value = bill.category;
      el.billAmount.value = bill.amount;
      el.billDueDate.value = bill.dueDate;
      el.billRecurring.checked = !!bill.recurring;
      el.billNotes.value = bill.notes || "";
      el.deleteBtn.classList.remove("hidden");
    } else {
      el.modalTitle.textContent = "Add Bill";
      el.billId.value = "";
      el.billDueDate.value = new Date().toISOString().slice(0, 10);
      el.deleteBtn.classList.add("hidden");
    }
    el.overlay.classList.remove("hidden");
  }

  function closeModal() {
    el.overlay.classList.add("hidden");
  }

  function nextMonth(dateStr) {
    const d = new Date(dateStr + "T00:00:00");
    d.setMonth(d.getMonth() + 1);
    return d.toISOString().slice(0, 10);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const id = el.billId.value || uid();
    const existingIndex = bills.findIndex((b) => b.id === id);
    const bill = {
      id,
      name: el.billName.value.trim(),
      category: el.billCategory.value,
      amount: parseFloat(el.billAmount.value) || 0,
      dueDate: el.billDueDate.value,
      recurring: el.billRecurring.checked,
      notes: el.billNotes.value.trim(),
      paid: existingIndex >= 0 ? bills[existingIndex].paid : false,
      paidOn: existingIndex >= 0 ? bills[existingIndex].paidOn : null,
    };

    if (existingIndex >= 0) bills[existingIndex] = bill;
    else bills.push(bill);

    await persist();
    render();
    closeModal();
    showToast(existingIndex >= 0 ? "Bill updated" : "Bill added");
  }

  async function handleDelete() {
    const id = el.billId.value;
    bills = bills.filter((b) => b.id !== id);
    await persist();
    render();
    closeModal();
    showToast("Bill deleted");
  }

  async function togglePaid(id) {
    const bill = bills.find((b) => b.id === id);
    if (!bill) return;
    bill.paid = !bill.paid;
    bill.paidOn = bill.paid ? new Date().toISOString() : null;

    // If recurring and now marked paid, auto-create next month's bill.
    if (bill.paid && bill.recurring) {
      const already = bills.some(
        (b) => b.name === bill.name && b.dueDate === nextMonth(bill.dueDate)
      );
      if (!already) {
        bills.push({
          ...bill,
          id: uid(),
          dueDate: nextMonth(bill.dueDate),
          paid: false,
          paidOn: null,
        });
      }
    }

    await persist();
    render();
  }

  function wireEvents() {
    el.fab.addEventListener("click", () => openModal(null));
    el.cancelBtn.addEventListener("click", closeModal);
    el.overlay.addEventListener("click", (e) => {
      if (e.target === el.overlay) closeModal();
    });
    el.form.addEventListener("submit", handleSubmit);
    el.deleteBtn.addEventListener("click", handleDelete);

    el.list.addEventListener("click", (e) => {
      const actionEl = e.target.closest("[data-action]");
      if (!actionEl) return;
      const id = actionEl.getAttribute("data-id");
      const action = actionEl.getAttribute("data-action");
      if (action === "toggle") togglePaid(id);
      else if (action === "edit") {
        const bill = bills.find((b) => b.id === id);
        if (bill) openModal(bill);
      }
    });

    el.chips.forEach((chip) => {
      chip.addEventListener("click", () => {
        el.chips.forEach((c) => c.classList.remove("active"));
        chip.classList.add("active");
        currentFilter = chip.getAttribute("data-filter");
        render();
      });
    });
  }

  async function init() {
    wireEvents();
    bills = await BillStorage.loadBills();
    render();
  }

  document.addEventListener("DOMContentLoaded", init);
})();
