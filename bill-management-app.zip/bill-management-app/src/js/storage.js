/**
 * Offline storage layer.
 *
 * Inside the packaged Android app, Capacitor's Preferences plugin
 * (native SharedPreferences) is used so data survives app restarts
 * with zero network dependency. When running in a plain browser
 * (e.g. during local web development) it transparently falls back
 * to localStorage so the app still works the same way.
 *
 * All app assets are bundled into the APK at build time, so nothing
 * in this app ever requires a network connection.
 */
(function (global) {
  const STORAGE_KEY = "bills.v1";

  function getNativePreferences() {
    // Capacitor exposes registered plugins on window.Capacitor.Plugins
    if (
      global.Capacitor &&
      global.Capacitor.Plugins &&
      global.Capacitor.Plugins.Preferences
    ) {
      return global.Capacitor.Plugins.Preferences;
    }
    return null;
  }

  async function loadBills() {
    const prefs = getNativePreferences();
    try {
      if (prefs) {
        const { value } = await prefs.get({ key: STORAGE_KEY });
        return value ? JSON.parse(value) : [];
      }
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (err) {
      console.error("Failed to load bills, starting fresh.", err);
      return [];
    }
  }

  async function saveBills(bills) {
    const serialized = JSON.stringify(bills);
    const prefs = getNativePreferences();
    try {
      if (prefs) {
        await prefs.set({ key: STORAGE_KEY, value: serialized });
      } else {
        localStorage.setItem(STORAGE_KEY, serialized);
      }
    } catch (err) {
      console.error("Failed to persist bills.", err);
    }
  }

  global.BillStorage = { loadBills, saveBills };
})(window);
